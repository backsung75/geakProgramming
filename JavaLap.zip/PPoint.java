/**
 @version 1.00 2022-11-29
 @author 성렬
 */

package kr.ac.kookmin.cs;
public class PPoint {
 int xA;
 int yA;
 /**
  * 
  * @param x
  * @param y
  */
 public PPoint(int x, int y) {
 xA = x;
 yA = y;
};
/**
 * 
 * @return
 */
 public int getX() {
 return xA;
 }
 /**
  * 
  * @return
  */
 public int getY() {
 return yA;
 }
}